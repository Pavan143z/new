import React from "react";
import { BrowserRouter, Route, Link, Switch } from "react-router-dom";

export const Header = () => {
  return (
    <BrowserRouter>
    <nav className="navbar navbar-expand-lg navbar-light bg-dark">
      <div className="container-fluid">
        <div className="navbar-header">
          <Link className="navbar-brand" to="/">
           Business and Social Site 
          </Link>
        </div>

        <div
          className="collapse navbar-collapse"
          id="bs-example-navbar-collapse-1"
        >
          <ul className="nav navbar-nav">
            <li className="active">
              <Link to="/home">
                Home<span className="sr-only" />
              </Link>
            </li>
{/*            
            <li>
              <Link to="/home">Home</Link>
            </li> */}

            <li>
              <Link to="/login">Login</Link>
            </li>


            <li>
              <Link to="/profile">Profiles</Link>
            </li>

            <li>
              <Link to="/viewjobs">view jobs</Link>
            </li>

            <li>
              <Link to="/card">view card</Link>
            </li>

          </ul>

          <ul className="nav navbar-nav navbar-right">
            <li><Link to="/register">Register</Link></li>
          </ul>

          <ul className="nav navbar-nav navbar-right">
            
          </ul>
        </div>
      </div>
    </nav>
    </BrowserRouter>
  );
};

export default Header;
