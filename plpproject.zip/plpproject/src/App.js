import React, { Component } from 'react';

import{BrowserRouter as Router,Route,Link,Switch} from 'react-router-dom';
import Navbar from './components/Organization/Navbar'
import ProfileDisplay from "./components/User/viewjobs"
import PostJob from './components/Organization/postjob'
import ManageJobs from './components/Organization/managejobs';
class App extends Component {
  render () {
    return (
     
       
      <Router>
   
      <div>
        
        <Navbar/>
        <div className="container">
        <Switch>
    
        <Route exact path="/managejob" component={ManageJobs}/>
         <Route exact path="/postjob" component={PostJob}/>
        
         <Route exact path="/viewjobs" component={ProfileDisplay} />
        </Switch>
        
        </div>
      </div>
  
    </Router>
         
       
    );
  }
}



export default App;
